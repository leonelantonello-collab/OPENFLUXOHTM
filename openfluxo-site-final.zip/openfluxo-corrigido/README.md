# OpenFluxo - Site Oficial

Site institucional da OpenFluxo, empresa especializada em automação inteligente, agentes de IA e marketing digital.

## 🚀 Tecnologias Utilizadas

- **HTML5**: Estrutura semântica e acessível
- **CSS3**: Estilização moderna com variáveis CSS, gradientes e animações
- **JavaScript**: Interatividade e animações dinâmicas
- **Particles.js**: Efeito de partículas animadas no fundo

## 📁 Estrutura do Projeto

```
openfluxo-site/
├── index.html              # Página principal
├── automacao.html          # Página de automação
├── agente-ia.html          # Página de agente IA
├── marketing.html          # Página de marketing
├── planos.html             # Página de planos
├── sobre.html              # Página sobre
├── contato.html            # Página de contato
├── css/
│   └── style.css           # Estilos principais
├── js/
│   ├── particles-config.js # Configuração do Particles.js
│   └── script.js           # Scripts principais
├── images/
│   └── openfluxo-logo.jpeg # Logo da empresa
└── README.md               # Este arquivo
```

## 🎨 Características

- **Design Futurista**: Interface moderna com tema dark e gradientes vibrantes
- **Responsivo**: Adaptável a todos os tamanhos de tela
- **Performance**: Otimizado para carregamento rápido
- **Acessibilidade**: Estrutura semântica e atributos ARIA
- **Animações Suaves**: Transições e efeitos visuais elegantes
- **SEO Otimizado**: Meta tags e estrutura adequada para mecanismos de busca

## 🎯 Funcionalidades

- Navegação suave entre seções
- Botão flutuante do WhatsApp
- Efeito de partículas animadas no fundo
- Cards interativos com hover effects
- Header com efeito de scroll
- Animações de fade-in ao rolar a página
- Links diretos para WhatsApp com mensagens pré-definidas

## 🔧 Como Usar

1. Clone o repositório ou faça o download dos arquivos
2. Abra o arquivo `index.html` em um navegador moderno
3. Não é necessário servidor local, mas recomendado para desenvolvimento

### Desenvolvimento Local

Para desenvolvimento, recomenda-se usar um servidor local:

```bash
# Com Python
python -m http.server 8000

# Com Node.js (http-server)
npx http-server

# Com PHP
php -S localhost:8000
```

Acesse: `http://localhost:8000`

## 📱 Responsividade

O site é totalmente responsivo e otimizado para:
- Desktop (1200px+)
- Tablet (768px - 1199px)
- Mobile (até 767px)

## 🎨 Paleta de Cores

- **Purple**: `#7C3AED` - Cor principal
- **Cyan**: `#06B6D4` - Cor secundária
- **Dark Background**: `hsl(220, 30%, 8%)` - Fundo principal
- **Card Background**: `hsl(220, 25%, 12%)` - Fundo dos cards
- **Border**: `hsl(220, 20%, 20%)` - Bordas
- **Text Primary**: `hsl(210, 40%, 98%)` - Texto principal
- **Text Muted**: `hsl(215, 20%, 65%)` - Texto secundário

## 📝 Customização

### Alterar Cores

Edite as variáveis CSS no arquivo `css/style.css`:

```css
:root {
  --purple: #7C3AED;
  --cyan: #06B6D4;
  /* ... outras variáveis */
}
```

### Alterar Partículas

Edite as configurações no arquivo `js/particles-config.js`:

```javascript
particlesJS('particles-js', {
  particles: {
    number: { value: 80 },
    color: { value: ['#7C3AED', '#06B6D4'] },
    // ... outras configurações
  }
});
```

## 🌐 Deploy

O site pode ser hospedado em qualquer serviço de hospedagem estática:

- **GitHub Pages**: Gratuito e fácil de configurar
- **Netlify**: Deploy automático via Git
- **Vercel**: Otimizado para performance
- **Cloudflare Pages**: CDN global integrado

### Deploy no GitHub Pages

1. Crie um repositório no GitHub
2. Faça o upload dos arquivos
3. Vá em Settings > Pages
4. Selecione a branch `main` e a pasta `/ (root)`
5. Clique em Save

Seu site estará disponível em: `https://seu-usuario.github.io/nome-do-repo`

## 📞 Contato

- **WhatsApp**: [+55 11 96446-7225](https://wa.me/5511964467225)
- **Email**: contato@openfluxo.com.br

## 📄 Licença

© 2025 OpenFluxo Tecnologia LTDA. Todos os direitos reservados.

---

Desenvolvido com ❤️ pela equipe OpenFluxo
