// OpenFluxo - Script Principal
(function() {
  'use strict';

  // Smooth scroll para links internos
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });

  // Adiciona classe ao header quando rolar a página
  let lastScroll = 0;
  const header = document.querySelector('header');
  
  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll <= 0) {
      header.classList.remove('scroll-up');
      return;
    }
    
    if (currentScroll > lastScroll && !header.classList.contains('scroll-down')) {
      // Scroll para baixo
      header.classList.remove('scroll-up');
      header.classList.add('scroll-down');
    } else if (currentScroll < lastScroll && header.classList.contains('scroll-down')) {
      // Scroll para cima
      header.classList.remove('scroll-down');
      header.classList.add('scroll-up');
    }
    lastScroll = currentScroll;
  });

  // Animação de fade-in para elementos quando aparecem na tela
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('fade-in-up');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  // Observa todos os cards e seções
  document.querySelectorAll('.card, section > .container > h2').forEach(el => {
    observer.observe(el);
  });

  // Prevenção de FOUC (Flash of Unstyled Content)
  document.documentElement.classList.add('js-enabled');

  // Log de inicialização
  console.log('%cOpenFluxo', 'font-size: 24px; font-weight: bold; color: #7C3AED;');
  console.log('%cAutomação Inteligente para o Futuro dos Negócios', 'font-size: 14px; color: #06B6D4;');

})();
