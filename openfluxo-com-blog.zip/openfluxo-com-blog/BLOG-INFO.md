# 📚 Blog OpenFluxo - Documentação

## Visão Geral

Blog interativo e dinâmico criado para substituir a página de planos, mantendo o estilo visual dark futurista do OpenFluxo.

---

## ✨ Características Principais

### 🎨 Design
- **Tema:** Dark futurista (mantido do arquivo de referência)
- **Cores:** Roxo (#7C3AED) e Ciano (#06B6D4)
- **Partículas:** Animadas no fundo
- **Layout:** Grid responsivo de 3 colunas

### 📝 Conteúdo
- **6 artigos** pré-carregados com imagens reais
- **Categorias:** Automação, IA, Marketing, Tutoriais, Cases
- **Metadados:** Data de publicação e tempo de leitura
- **Imagens:** Do Unsplash (alta qualidade)

### 🔍 Funcionalidades Interativas

#### 1. Busca em Tempo Real
- Campo de busca com ícone
- Filtra por título e descrição
- Debounce de 300ms para performance
- Busca ao pressionar Enter

#### 2. Filtros por Categoria
- 6 botões de categoria
- Filtro "Todos" ativo por padrão
- Animação ao clicar
- Combinável com busca

#### 3. Cards Interativos
- **Hover:** Elevação e borda colorida
- **Imagem:** Zoom suave ao hover
- **Badge:** Categoria colorida
- **Animação:** Fade-in escalonado
- **Barra superior:** Gradiente ao hover

#### 4. Load More
- Botão "Carregar Mais Artigos"
- Animação de loading
- Simula carregamento de 3 artigos
- Desabilita após carregar todos

#### 5. Newsletter
- Formulário de inscrição
- Validação de e-mail
- Animação de sucesso
- Feedback visual

---

## 📁 Estrutura de Arquivos

```
openfluxo-com-blog/
├── blog.html (16.9 KB)
├── css/
│   ├── style.css (tema principal)
│   └── blog.css (estilos do blog - 6.5 KB)
├── js/
│   ├── particles-config.js
│   └── blog.js (interatividade - 5.2 KB)
└── images/
    └── openfluxo-logo.jpeg
```

---

## 🎯 Funcionalidades JavaScript

### Filtro de Posts
```javascript
function filterPosts() {
  // Filtra por categoria E busca
  // Mostra/esconde cards
  // Exibe "sem resultados" se necessário
}
```

### Busca
```javascript
searchInput.addEventListener('input', function() {
  // Debounce de 300ms
  // Atualiza currentSearchTerm
  // Chama filterPosts()
});
```

### Categorias
```javascript
categoryBtns.forEach(btn => {
  btn.addEventListener('click', function() {
    // Remove active de todos
    // Adiciona active no clicado
    // Atualiza categoria
    // Filtra posts
  });
});
```

### Load More
```javascript
loadMoreBtn.addEventListener('click', function() {
  // Mostra loading
  // Simula carregamento (1.5s)
  // Incrementa contador
  // Desabilita se todos carregados
});
```

### Newsletter
```javascript
newsletterForm.addEventListener('submit', function(e) {
  e.preventDefault();
  // Valida e-mail
  // Animação de envio
  // Feedback de sucesso
});
```

---

## 🎨 CSS Customizado

### Cards com Efeitos
```css
.blog-card {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid var(--border-color);
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.blog-card:hover {
  transform: translateY(-8px);
  border-color: var(--purple);
  box-shadow: 0 20px 60px rgba(124, 58, 237, 0.3);
}
```

### Barra Gradiente
```css
.blog-card::before {
  content: '';
  height: 3px;
  background: linear-gradient(90deg, var(--purple), var(--cyan));
  transform: scaleX(0);
}

.blog-card:hover::before {
  transform: scaleX(1);
}
```

### Animações Escalonadas
```css
.blog-card:nth-child(1) { animation-delay: 0.1s; }
.blog-card:nth-child(2) { animation-delay: 0.2s; }
.blog-card:nth-child(3) { animation-delay: 0.3s; }
/* ... */
```

---

## 📊 Artigos Incluídos

### 1. Como a IA Generativa está Transformando o Atendimento ao Cliente
- **Categoria:** Inteligência Artificial
- **Data:** 02 Nov 2025
- **Leitura:** 5 min
- **Imagem:** IA/Tecnologia

### 2. 10 Processos que Você Pode Automatizar Hoje Mesmo
- **Categoria:** Automação
- **Data:** 30 Out 2025
- **Leitura:** 7 min
- **Imagem:** Dashboard/Analytics

### 3. WhatsApp Marketing: Estratégias que Convertem
- **Categoria:** Marketing Digital
- **Data:** 28 Out 2025
- **Leitura:** 6 min
- **Imagem:** Marketing/Dados

### 4. Passo a Passo: Configurando seu Primeiro Chatbot
- **Categoria:** Tutoriais
- **Data:** 25 Out 2025
- **Leitura:** 10 min
- **Imagem:** Tutorial/Laptop

### 5. Como uma Clínica Reduziu 70% das Faltas com Automação
- **Categoria:** Cases de Sucesso
- **Data:** 22 Out 2025
- **Leitura:** 8 min
- **Imagem:** Equipe/Reunião

### 6. O Futuro do Trabalho: IA como Parceira, não Substituta
- **Categoria:** Inteligência Artificial
- **Data:** 20 Out 2025
- **Leitura:** 12 min
- **Imagem:** Robô/IA

---

## 🔗 Navegação Atualizada

### Antes
```html
<a href="planos.html">Planos</a>
```

### Depois
```html
<a href="blog.html">Blog</a>
```

**Páginas atualizadas:**
- ✅ index.html
- ✅ automacao.html
- ✅ agente-ia.html
- ✅ marketing.html
- ✅ sobre.html
- ✅ contato.html
- ✅ blog.html (nova)

**Página removida:**
- ❌ planos.html

---

## 📱 Responsividade

### Desktop (> 768px)
- Grid de 3 colunas
- Busca horizontal
- Newsletter horizontal

### Mobile (≤ 768px)
- Grid de 1 coluna
- Busca vertical
- Newsletter vertical
- Categorias em wrap
- Cards com altura reduzida

---

## ⚡ Performance

### Otimizações
- **Debounce:** 300ms na busca
- **Lazy Loading:** Imagens do Unsplash
- **CSS Animations:** GPU accelerated
- **Event Delegation:** Onde possível
- **Intersection Observer:** Para animações

### Métricas Esperadas
- **First Contentful Paint:** < 1.5s
- **Time to Interactive:** < 2.5s
- **Largest Contentful Paint:** < 3s

---

## 🎯 Próximas Melhorias

### Funcionalidades Futuras
1. **Paginação real** (backend necessário)
2. **Sistema de comentários**
3. **Compartilhamento social**
4. **Tags adicionais**
5. **Artigos relacionados**
6. **Modo leitura**
7. **Favoritos**
8. **RSS Feed**

### Integrações Possíveis
1. **CMS Headless** (Strapi, Contentful)
2. **Analytics** (Google Analytics)
3. **Newsletter** (Mailchimp, SendGrid)
4. **Busca Avançada** (Algolia)
5. **SEO** (Meta tags dinâmicas)

---

## 🚀 Como Usar

### 1. Adicionar Novo Artigo

```html
<article class="blog-card" data-category="CATEGORIA">
  <div class="blog-card-image">
    <img src="URL_IMAGEM" alt="Título">
    <div class="blog-card-badge">CATEGORIA</div>
  </div>
  <div class="blog-card-content">
    <div class="blog-card-meta">
      <span class="blog-date">
        <!-- SVG do calendário -->
        DATA
      </span>
      <span class="blog-read-time">X min de leitura</span>
    </div>
    <h3>Título do Artigo</h3>
    <p>Descrição breve do artigo...</p>
    <a href="#" class="blog-read-more">
      Ler artigo
      <!-- SVG da seta -->
    </a>
  </div>
</article>
```

### 2. Adicionar Nova Categoria

```html
<!-- HTML -->
<button class="category-btn" data-category="nova-categoria">
  Nova Categoria
</button>
```

```html
<!-- Badge no card -->
<div class="blog-card-badge">Nova Categoria</div>
```

### 3. Personalizar Cores

```css
/* css/blog.css */
.blog-card-badge {
  background: rgba(SUA_COR, 0.9);
}
```

---

## 📞 Suporte

Para dúvidas ou suporte:
- **Email:** contato@openfluxo.com.br
- **WhatsApp:** Link no site

---

**Criado por:** Manus AI  
**Data:** 03 de Novembro de 2025  
**Versão:** 1.0 - Blog Interativo  
**Status:** ✅ Completo e Funcional
