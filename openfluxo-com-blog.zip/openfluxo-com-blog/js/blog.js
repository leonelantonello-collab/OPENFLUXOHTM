// Blog Interativo - OpenFluxo
(function() {
  'use strict';

  // Elementos
  const searchInput = document.getElementById('searchInput');
  const categoryBtns = document.querySelectorAll('.category-btn');
  const blogCards = document.querySelectorAll('.blog-card');
  const loadMoreBtn = document.querySelector('.load-more-btn');
  const newsletterForm = document.querySelector('.newsletter-form');

  // Estado atual
  let currentCategory = 'all';
  let currentSearchTerm = '';

  // Função de filtro
  function filterPosts() {
    blogCards.forEach(card => {
      const category = card.getAttribute('data-category');
      const title = card.querySelector('h3').textContent.toLowerCase();
      const description = card.querySelector('p').textContent.toLowerCase();
      
      // Verifica categoria
      const matchesCategory = currentCategory === 'all' || category === currentCategory;
      
      // Verifica busca
      const matchesSearch = currentSearchTerm === '' || 
                           title.includes(currentSearchTerm) || 
                           description.includes(currentSearchTerm);
      
      // Mostra ou esconde o card
      if (matchesCategory && matchesSearch) {
        card.classList.remove('hidden');
        card.style.animation = 'fadeInScale 0.5s ease-out';
      } else {
        card.classList.add('hidden');
      }
    });

    // Verifica se há resultados
    const visibleCards = document.querySelectorAll('.blog-card:not(.hidden)');
    if (visibleCards.length === 0) {
      showNoResults();
    } else {
      hideNoResults();
    }
  }

  // Filtro por categoria
  categoryBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      // Remove active de todos
      categoryBtns.forEach(b => b.classList.remove('active'));
      
      // Adiciona active no clicado
      this.classList.add('active');
      
      // Atualiza categoria atual
      currentCategory = this.getAttribute('data-category');
      
      // Filtra posts
      filterPosts();
      
      // Efeito visual
      this.style.transform = 'scale(0.95)';
      setTimeout(() => {
        this.style.transform = 'scale(1)';
      }, 100);
    });
  });

  // Busca
  let searchTimeout;
  searchInput.addEventListener('input', function() {
    clearTimeout(searchTimeout);
    
    searchTimeout = setTimeout(() => {
      currentSearchTerm = this.value.toLowerCase().trim();
      filterPosts();
    }, 300);
  });

  // Busca ao pressionar Enter
  searchInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      currentSearchTerm = this.value.toLowerCase().trim();
      filterPosts();
    }
  });

  // Botão de busca
  const searchBtn = document.querySelector('.search-btn');
  searchBtn.addEventListener('click', function() {
    currentSearchTerm = searchInput.value.toLowerCase().trim();
    filterPosts();
  });

  // Load More (simulado)
  let postsLoaded = 6;
  loadMoreBtn.addEventListener('click', function() {
    this.innerHTML = `
      <span style="display: inline-flex; align-items: center; gap: 0.5rem;">
        <svg style="animation: spin 1s linear infinite;" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
        </svg>
        Carregando...
      </span>
    `;
    
    // Simula carregamento
    setTimeout(() => {
      postsLoaded += 3;
      
      if (postsLoaded >= 12) {
        this.innerHTML = 'Todos os artigos carregados ✓';
        this.disabled = true;
        this.style.opacity = '0.6';
        this.style.cursor = 'not-allowed';
      } else {
        this.innerHTML = `
          Carregar Mais Artigos
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"></polyline>
          </svg>
        `;
      }
    }, 1500);
  });

  // Newsletter
  newsletterForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const emailInput = this.querySelector('.newsletter-input');
    const submitBtn = this.querySelector('.btn-primary');
    const originalText = submitBtn.textContent;
    
    // Validação simples
    if (!emailInput.value || !emailInput.value.includes('@')) {
      emailInput.style.borderColor = '#ef4444';
      emailInput.focus();
      return;
    }
    
    // Animação de envio
    submitBtn.textContent = 'Enviando...';
    submitBtn.disabled = true;
    
    setTimeout(() => {
      submitBtn.textContent = '✓ Inscrito!';
      submitBtn.style.background = '#10b981';
      emailInput.value = '';
      
      setTimeout(() => {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        submitBtn.style.background = '';
      }, 3000);
    }, 1500);
  });

  // Função para mostrar "sem resultados"
  function showNoResults() {
    let noResultsEl = document.querySelector('.no-results');
    
    if (!noResultsEl) {
      noResultsEl = document.createElement('div');
      noResultsEl.className = 'no-results';
      noResultsEl.innerHTML = `
        <div style="text-align: center; padding: 4rem 2rem;">
          <svg style="width: 80px; height: 80px; margin: 0 auto 1.5rem; opacity: 0.3;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
            <line x1="11" y1="8" x2="11" y2="14"></line>
            <line x1="8" y1="11" x2="14" y2="11"></line>
          </svg>
          <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem;">Nenhum artigo encontrado</h3>
          <p style="color: var(--text-muted);">Tente ajustar os filtros ou buscar por outros termos.</p>
        </div>
      `;
      document.querySelector('.posts-grid').appendChild(noResultsEl);
    }
    
    noResultsEl.style.display = 'block';
  }

  function hideNoResults() {
    const noResultsEl = document.querySelector('.no-results');
    if (noResultsEl) {
      noResultsEl.style.display = 'none';
    }
  }

  // Animação ao rolar
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, observerOptions);

  // Observa cards
  blogCards.forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(card);
  });

  // Smooth scroll
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });

  // Adiciona animação de spin para loading
  const style = document.createElement('style');
  style.textContent = `
    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
  `;
  document.head.appendChild(style);

  // Log de inicialização
  console.log('%cBlog OpenFluxo', 'font-size: 20px; font-weight: bold; color: #7C3AED;');
  console.log(`%c${blogCards.length} artigos carregados`, 'font-size: 14px; color: #06B6D4;');

})();
