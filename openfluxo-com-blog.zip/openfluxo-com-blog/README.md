# OpenFluxo - Site HTML Estático

Site futurista dark com tema roxo (#7C3AED) e ciano (#06B6D4).

## Páginas Incluídas
- index.html - Página inicial
- automacao.html - Automação para clínicas
- agente-ia.html - Agente IA humanizado
- marketing.html - Marketing e tráfego pago
- planos.html - Comparativo de planos
- sobre.html - Sobre a OpenFluxo
- contato.html - Formulário de contato

## Estrutura
- css/ - Estilos globais
- js/ - Scripts de animações
- images/ - Logo e imagens

## Como Usar
1. Descompacte o arquivo ZIP
2. Abra index.html no navegador
3. Todos os links e navegação funcionam offline

## Tecnologias
- HTML5 puro
- CSS3 com animações
- Particles.js para efeito de fundo
- Responsivo (mobile + desktop)

© 2025 OpenFluxo Tecnologia LTDA
